package Prueba_paquetes;
import java.util.Scanner;
import static paquetessecundarios.NumeroPrimo.NumeroPrimo1;
import static paquetessecundarios.NumeroMayor.NumeroMayor1;
import static paquetessecundarios.RestaSucesiva.RestaSucesiva1;
import static paquetessecundarios.Factorial.Factorial1;
import static paquetessecundarios.SumaSucesiva.SumaSucesiva1;
import static paquetessecundarios.MayorAMenor.MayorAMenor1;
import static paquetessecundarios.Potencia.Potencia1;
/**
 *
 * @author Miguel 
 */
public class Paquetes {
    
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        //Menu desplejable
            int Eleccion = 0;
            boolean Menu = true;
                while(Menu){
                System.out.println("\n SELECCIONE UNA OPCION:");
                System.out.println("\n 1-CALCULAR SI ES PRIMO N NUMERO");
                System.out.println("\n 2-CALCULAR EL MAYOR DE DOS NUMEROS");
                System.out.println("\n 3-OBTENER COCIENTE Y RESIDUO POR RESTA SUCESIVAS ");
                System.out.println("\n 4-OBTENER EL 1PRODUCTO DE DOS NUMEROS MEDIANTE SUMAS SUCESIVAS");
                System.out.println("\n 5-ORDENAR 10 NUMEROS DE MENOR A MAYOR");
                System.out.println("\n 6-OBTENER EL FACTORIAL DE UN NUMERO ");
                System.out.println("\n 7-OBTENER LA POTENCIA DE UN NUMERO");
                System.out.println("\n 8-SALIR");
                Eleccion = Leer.nextInt();
                if (Eleccion >= 1 && Eleccion <= 8) {
                    switch (Eleccion) 
                    {
                        //Mis casos
                        case 1:
                            NumeroPrimo1();
                            System.out.println("-----------------------------");
                            break;
                        case 2:
                            NumeroMayor1();
                            System.out.println("-----------------------------");
                            break;
                        case 3:
                            RestaSucesiva1();
                            System.out.println("-----------------------------");
                            break;
                        case 4:
                            SumaSucesiva1();
                            System.out.println("-----------------------------");
                            break;
                        case 5:
                            MayorAMenor1();
                            System.out.println("-----------------------------");
                            break;
                        case 6:
                            Factorial1();
                            System.out.println("-----------------------------");
                            break;
                        case 7:
                           Potencia1();
                           System.out.println("-----------------------------");
                            break;
                        case 8:
                          Menu=false;
                            System.out.println("Fin del programa");
                          break;
                    }
                    
                }
                System.out.println("\n ========================================");
                    System.out.println(" ELABORÓ: MIGUEL ANGEL MELCHI ALAJARA");
                     System.out.println("\n ========================================");
                     System.gc();
            }        
    }
}