
package paquetessecundarios;

import java.util.Scanner;
/**
 *
 * @author Miguel
 */
public class Factorial {    
        public static void Factorial1() {
            Scanner Leer = new Scanner(System.in);
            System.out.println("SELECCIONO : OPCION 6 ");
            int i=1;
            //inserccion de numeros
            int numero=0;
            int factorial=1;
            System.out.println("Numero: "+numero);
            while(i<=numero){
                factorial=factorial*i;
                i=i+1;
            }
            System.out.println("El factorial de "+numero+" es: "+factorial);
        }
}
