
package paquetessecundarios;

import java.util.Scanner;
/**
 *
 * @author Miguel
 */
public class MayorAMenor {
        public static void MayorAMenor1() {
            Scanner Leer = new Scanner(System.in);
            System.out.println("SELECCIONO : OPCION  5");
             //inserccion de numeros
            int Numeros[]={10,11,12,13,14,15,16,17,18,19};
            System.out.println("Numeros a Ordenar");
                for(int i=0; i<10; i++){
                    System.out.println(Numeros[i]);
                }
                for(int i=0; i<9; i++){
                    int may=i;
                    for(int j=i+1; j<10; j++){
                        if (Numeros[j]>Numeros[may]){
                            may=j; 
                        }
                        if (i!=may){
                            int aux=Numeros[i];
                            Numeros[i]=Numeros[may];
                            Numeros[may]=aux;
                            }
                    }
                }
                System.out.println("Numeros Ordenados :");
                for(int k=0; k<10; k++){
                    System.out.println(Numeros[k]);
                }            
        }
}

