
package paquetessecundarios;
import java.util.Scanner;
/**
 *
 * @author Miguel
 */
public class NumeroMayor {
        public static void NumeroMayor1() {
            Scanner Leer = new Scanner(System.in);
             //inserccion de numeros
            int Numero1=5;
            int Numero2=8;
            int c=0,i;
            System.out.println("SELECCIONO : OPCION 2 ");
            System.out.println("Numero 1: "+Numero1); 
            System.out.println("Numero 2: "+Numero2);
            if(Numero1>Numero2){
                System.out.println("EL NUMERO MAYOR ES:" +Numero1);
            }
            if(Numero1<Numero2){
                System.out.println("EL NUMERO MAYOR ES:" +Numero2);
            }
            if(Numero1==Numero2){
                System.out.println("LOS NUMEROS SON IGUALES.");
            }

        }
}
