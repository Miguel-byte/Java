
package paquetessecundarios;

import java.util.Scanner;

/**
 *
 * @author Miguel
 */
public class NumeroPrimo {
        public static void NumeroPrimo1() {
            Scanner Leer = new Scanner(System.in);
             //inserccion de numeros
            int Numero=15;
            int c=0,i;
            System.out.println("SELECCIONO : OPCION NUMERO 1 ");
            System.out.println("Numero: "+Numero);
            for(i=1; i<(Numero+1);i++){
                if (Numero%i==0){
                    c++;
                }
            }if(c!=2){
                System.out.println(Numero+ " No es un numero primo.");
            }else{
                System.out.println(Numero+ " Si es un numero primo.");
            }   
        }    
}
