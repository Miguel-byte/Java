
package paquetessecundarios;

import java.util.Scanner;
/**
 *
 * @author Miguel
 */
public class Potencia {
        public static void Potencia1() {
            Scanner Leer = new Scanner(System.in);
            System.out.println("SELECCIONO: OPCION 7");
             //inserccion de numeros
            int Numero=5;
            System.out.println("Base a elevar: "+Numero);
            int Potencia=5;
            System.out.println("Potencia: "+Potencia);
            int Total=(int) Math.pow(Numero, Potencia);
            System.out.println("El resultado de la potecia es : "+Total);
        }
}