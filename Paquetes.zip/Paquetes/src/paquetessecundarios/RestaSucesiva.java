
package paquetessecundarios;

/**
 *
 * @author Miguel
 */
public class RestaSucesiva {
    
            public static void RestaSucesiva1() {
                int Dividendo,Divisor,Cociente,Residuo=0;
                String c1,c2,ax;
                int op, dividendo;
                System.out.println("SELECCIONO : OPCION 3 ");
                    //inserccion de numeros
                c1="10";
                c2="3";
                System.out.println("Dividendo: "+c1);
                System.out.println("Divisor: "+c2);
                Dividendo=Integer.parseInt(c1);
                Divisor=Integer.parseInt(c2);
                dividendo=Dividendo;
                int c=0;
                c = 0;
                int n1=Dividendo;
                int n2=Divisor;
                while(n1>=n2){      
                    n1=n1-n2;
                    c++;
                }
                Dividendo=n1;
                Cociente=c;
                if(Dividendo!=0){
                    c = 0;
                    Residuo=n1*10;
                    n2=Divisor;
                    while(Residuo>=n2){      
                        Residuo=Residuo-n2;
                        c++;
                    }
                    Residuo=c;
                    System.out.println("El resultado es: "+Cociente+"."+Residuo);
                }else{
                    System.out.println("El Resultado es: "+Cociente);
                }
                System.out.println("El cociente es: "+Cociente);
            }
}
