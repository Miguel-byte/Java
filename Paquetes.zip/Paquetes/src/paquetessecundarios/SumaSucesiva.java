
package paquetessecundarios;

import java.util.Scanner;
/**
 *
 * @author Miguel
 */
public class SumaSucesiva {
        public static void SumaSucesiva1() {
            Scanner Leer = new Scanner(System.in);
            System.out.println("SELECCIONO : OPCION 4");
             //inserccion de numeros
            int Numero1=5;
            int Numero2=8;
            int x,Producto;
            System.out.println("Numero a multiplicar: "+Numero1);
            System.out.println("Numero Multiplicador: "+Numero2);
            Producto=0;
            x=0;
            while(x<Numero1){
                Producto=Producto+Numero2;
                x=x+1;
            }
            System.out.println("El producto es: "+Producto);
        }
}