package proarbol;
public class Nodos {
    int dato;
    Nodos ladoIzq;
    Nodos ladoDer;
    
    public Nodos(int d){
        this.dato=d;
        this.ladoDer=null;
        this.ladoIzq=null;
    }
}