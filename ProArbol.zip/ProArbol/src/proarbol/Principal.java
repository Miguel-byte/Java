package proarbol;
import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        Scanner nodo=new Scanner(System.in);
        
        int op;
        int elemento;
        
        ProArbol arbol=new ProArbol();
        try{
            do {
                System.out.println("MENÚ PRINCIPAL");
                System.out.println("1. Crear el nodo raíz");
                System.out.println("2. Insertar un nodo en el árbol");
                System.out.println("3. Eliminar un nodo en el árbol");
                System.out.println("4. Buscar un nodo en el árbol");
                System.out.println("5. Recorrer el árbol");
                System.out.println("6. Salir\n");
                
                System.out.print("Seleccione opción: ");
                
                op=nodo.nextInt();
                
                System.out.println();
                
                switch(op){
                    case 1:
                        
                        System.out.print("Escriba la información del nodo: ");
                        elemento=nodo.nextInt();
                        
                        System.out.println();
                        
                        arbol.crearNodo(elemento);
                        System.out.println();
                        
                        break;
                        
                    case 2:
                        
                        if(!arbol.Vacio()){
                        String res;
                        
                        do{
                            System.out.print("Escriba la información del nodo: ");
                            elemento=nodo.nextInt();
                            
                            arbol.insertarNodo(elemento);
                            
                            System.out.print("¿Desea otra inserción (s/n)? ");
                            res=nodo.next();
                            
                            System.out.println();
                        
                        }while(!res.equals("n"));
                        
                        }else{
                            System.out.println("No hay raíz en el árbol\n");
                        }
                        break;
                        
                    case 3:
                        
                        if (!arbol.Vacio()) {
                            
                            System.out.print("Escriba la información a Eliminar: ");
                            elemento=nodo.nextInt();
                            
                            System.out.println();
                            
                            if (arbol.eliminar(elemento)==false) {
                                System.out.println("La información no está en el árbol\n");
                            }else{
                                System.out.println("El nodo ha sido eliminado\n");
                            }
                        }
                        break;
                        
                    case 4:
                        
                        if (!arbol.Vacio()) {
                            
                            String res;
                            
                            do{
                            
                            System.out.print("Escriba la información a buscar: ");
                            elemento=nodo.nextInt();
                            
                            arbol.buscarNodo(elemento);
                            
                            if (arbol.buscarNodo(elemento)==null) {
                            
                                System.out.println("La información NO está dentro del árbol\n");
                                System.out.print("¿Desea otra búsqueda (s/n)?");
                                res=nodo.next();
                                
                            }
                            else{
                                
                                System.out.println("La información SI está dentro del árbol\n");
                                System.out.print("¿Desea otra búsqueda (s/n)?");
                                res=nodo.next();
                                
                            }
                            }
                            while(!res.equals("n"));
                        }else{
                            System.out.println("No hay nodo raíz en el árbol\n");
                        }
                        break;
                        
                    case 5:
                        
                        int opcion;
                        if(!arbol.Vacio()){
                        do{
                            System.out.println("\nMenú de Recorrido:");
                            System.out.println("1. InOrden");
                            System.out.println("2. PreOrden");
                            System.out.println("3. PostOrden");
                            System.out.println("4. Regresar al menú principal\n");
                            System.out.print("Seleccione la opción: ");
                            
                            opcion=nodo.nextInt();
                            
                            System.out.println();
                            
                            switch(opcion){
                            
                                case 1:
                                    
                                    if (!arbol.Vacio()) {
                                        System.out.println("Información de InOrden:");
                                        arbol.inOrden(arbol.raiz);
                                        System.out.println();
                                    }
                                    
                                    break;
                                    
                                case 2:
                                    
                                    if (!arbol.Vacio()) {
                                        System.out.println("Información de PreOrden:");
                                        arbol.preOrden(arbol.raiz);
                                        System.out.println();
                                    }
                                    
                                    break;
                                    
                                case 3:
                                    
                                    if (!arbol.Vacio()) {
                                        System.out.println("Información de PostOrden:");
                                        arbol.postOrden(arbol.raiz);
                                        System.out.println();
                                    }
                                    
                                    break;
                                }
                            }while(opcion!=4);
                        }
                        else{
                            System.out.println("No hay nodo raíz en el árbol\n");
                        }
                        break;
                    }
                } while (op!=6);
            } catch (NumberFormatException e) {
        }
    }
}