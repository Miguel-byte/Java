package proarbol;
public class ProArbol {
    Nodos raiz;
    Nodos nuevo;
    
    public ProArbol(){
        raiz=null;
    }
    
    public void crearNodo(int d){
        
        nuevo=new Nodos(d);
        
        if (raiz==null) {
            raiz=nuevo;
            System.out.println("El nodo ha sido creado");
        }else{
            System.out.println("El nodo raíz ya existe");
        }
    }
    
    public void insertarNodo(int d){
        
        Nodos aux=raiz;
        nuevo=new Nodos(d);
        Nodos padre;
        
        while(true){
               padre=aux;
        
           if (d<aux.dato) {
                aux=aux.ladoIzq;
                if (aux==null) {
                    padre.ladoIzq=nuevo;
                return;
                }
            }else{
                aux=aux.ladoDer;
                if (aux==null) {
                    padre.ladoDer=nuevo;
                return;
                }
            }
        }
    }
    //Árbol vacío
    public boolean Vacio(){
        return raiz==null;
    }
    
    //Árbol InOrden
    public void inOrden(Nodos r){
        
        if (r!=null) {
            inOrden(r.ladoIzq);
            System.out.print(r.dato + ", ");
            inOrden(r.ladoDer);
        }
    }
    
    //Árbol PreOrden
    public void preOrden(Nodos r){
        
        if (r!=null) {
            System.out.print(r.dato + ", ");
            preOrden(r.ladoIzq);
            preOrden(r.ladoDer);
        }
    }
    
    //Árbol PostOrden
    public void postOrden(Nodos r){
        
        if (r!=null) {
            postOrden(r.ladoIzq);
            postOrden(r.ladoDer);
            System.out.print(r.dato + ", ");
        }
    }
    
    public boolean eliminar(int d){
        
        Nodos aux=raiz;
        Nodos padre=raiz;
        boolean esLadoIzq=true;
        
        while(aux.dato!=d){
            
            padre=aux;
        
            if (d<aux.dato) {
                esLadoIzq=true;
                aux=aux.ladoIzq;
            }
            else{
                esLadoIzq=false;
                aux=aux.ladoDer;
            }
            if (aux==null) {
                return false;
            }
        }
        
        if (aux.ladoIzq==null && aux.ladoDer==null) {
            
            if (aux==raiz) {
                raiz=null;
            }
            else if(esLadoIzq){
                padre.ladoIzq=null;
            }
            else{
                padre.ladoDer=null;
            }
        }
        else if(aux.ladoDer==null){
        
            if (aux==raiz) {
                raiz=aux.ladoIzq;
            }
            else if(esLadoIzq){
                padre.ladoIzq=aux.ladoIzq;
            }
            else{
                padre.ladoDer=aux.ladoIzq;
            }
        }
        else if(aux.ladoIzq==null){
        
            if (aux==raiz) {
                raiz=aux.ladoDer;
            }
            else if(esLadoIzq){
                padre.ladoIzq=aux.ladoDer;
            }
            else{
                padre.ladoDer=aux.ladoIzq;
            }
        }
        else{
            
            Nodos reemplazo=obtenerNodoReemplazo(aux);
           
            if (aux==raiz) {
                raiz=reemplazo;
            }
            else if(esLadoIzq){
                padre.ladoIzq=reemplazo;
            }
            else{
                padre.ladoDer=reemplazo;
            }
            reemplazo.ladoIzq=aux.ladoIzq;
        }
        
        return true;
    }
    public Nodos obtenerNodoReemplazo(Nodos nodReem){
        
        Nodos reemplazarPa=nodReem;
        Nodos reemplazo=nodReem;
        Nodos aux=nodReem.ladoDer;
        
        while(aux!=null){
            reemplazarPa=reemplazo;
            reemplazo=aux;
            aux=aux.ladoIzq;
        }
        
        if (reemplazo!=nodReem.ladoDer) {
            reemplazarPa.ladoIzq=reemplazo.ladoDer;
            reemplazo.ladoDer=nodReem.ladoDer;
        }
        return reemplazo;
    }
    
    //Método de búsqueda en el árbol
    public Nodos buscarNodo(int n){
        
        Nodos aux=raiz;
        
        while(aux.dato!=n){
            
            if (n<aux.dato) {
                aux=aux.ladoIzq;
            }
            else{
                aux=aux.ladoDer;
            }
            if (aux==null) {
                return null;
            }
        }
        return aux;
    }
}
